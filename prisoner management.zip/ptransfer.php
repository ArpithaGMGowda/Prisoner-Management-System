<?php
$host="localhost";
		$user="root";
		$pass="root";
		$db="ma";
		$conn=mysqli_connect($host,$user,$pass,$db);
		$from_prison="";
$to_prison="";
$reason="";
$transfer_id="";
$pno="";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
	$conn=mysqli_connect($host,$user,$pass,$db);

}catch(MYSQLI_sql_Exception $ex){
	
}
function getData(){
	$data=array();
	$data[0]=$_POST['from_prison'];
$data[1]=$_POST['to_prison'];
$data[2]=$_POST['reason'];
$data[3]=$_POST['transfer_id'];
$data[4]=$_POST['pno'];

	return $data;
}
if(isset($_POST['Insert'])){
	$info=getData();
	$insert_query="INSERT INTO `transfer_to`(`from_prison`, `to_prison`, `reason`, `transfer_id`, `pno`) VALUES ('$info[0]','$info[1]','$info[2]','$info[3]','$info[4]')";

	try{
		//echo("hi");
		$insert_result=mysqli_query($conn,$insert_query);
			//echo("helo");
		if($insert_result){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}
$insert_query1="INSERT INTO `transfer_to`(`from_prison`, `to_prison`, `reason`, `transfer_id`, `pno`) VALUES ('$info[0]','$info[1]','$info[2]','$info[3]','$info[4]')"; 

	try{
		//echo("hi");
		$insert_result1=mysqli_query($conn,$insert_query1);
			//echo("helo");
		if($insert_result1){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}
}


?>
<html>
<head>
<script>

    }
}
</script>
<title>Transfer form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table border="0" bgcolor="silver" align="center" width="54%">
<tr bgcolor="black">
<td align="center">
<font size="5">
<a href="admin.php">Home</a> 
</font>
</td>
</tr>
<tr>
<td>
<div>
		<center>
<form action="ptransfer.php" method="post">
<table bgcolor="white" height="450" border="0" align="center" width="50%">
	<b>from_prison:</b><input type="text" name="from_prison" placeholder="from_prison" value="<?php echo($from_prison);?>"><br><br>
<b>to_prison:</b><input type="text" name="to_prison" placeholder="to_prison" value="<?php echo($to_prison);?>"><br><br>
<b>reason:</b><input type="text" name="reason" placeholder="reason" value="<?php echo($reason);?>"><br><br>
<b>transfer_id:</b><input type="text" name="transfer_id" placeholder="transfer_id" value="<?php echo($transfer_id);?>"><br><br>
<b>pno:</b><input type="text" name="pno" placeholder="pno" value="<?php echo($pno);?>"><br/>
<input type="submit" name="Insert" value="Add" />

</table>
</form>
</center>


<tr>
	<center>
<a href="admin.php"><<<<<button>BACK</button><<<<</a></center>
	
<td height="21" colspan="2" align="center" bgcolor="silver">2018 BENGALURU PRISON SERVICES</td>
</body>
</html>
