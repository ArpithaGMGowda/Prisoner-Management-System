<html>
<head>
  <title>Case file Prisoners  </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='#999999' valign='center'>

<?php

$host="localhost";
$username="root";
$password="root";
$db_name="ma";
$tbl_name="court,prisoner";

$con=mysqli_connect("$host","$username","$password",$db_name) or die("cannot connect");
mysqli_select_db($con,"$db_name") or die("cannot connect"); 

$sel= mysqli_query($con,"select name,pid,court.warrentno,court.section,court.sentence,court.date_of_trial from court,prisoner where warrentno=wno");
echo"<table align='center' width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='silver'>
<caption><h3>CASE INFORMATION</h3></caption>
<tr bgcolor='#CCCCCC'>
<th width='3%'>name</th>
<th width='3%'>pid</th>
<th width='3%'>warrentno</th>
<th width='10%'>section</th>
<th width='10%'>sentence</th>
<th width='15%'>date_of_trial</th>
</tr>";

   while($row=mysqli_fetch_array ($sel))
{
echo "<tr bgcolor='white'>";
echo  "<td width='3%'>".$row ['name']."</td>";
echo  "<td width='3%'>".$row ['pid']."</td>";
echo  "<td width='3%'>".$row ['warrentno']."</td>";
echo  "<td width='7%'>".$row ['section']."</td>";
echo  "<td width='10%'>".$row ['sentence']."</td>";
echo  "<td width='10%'>".$row ['date_of_trial']. "</td>";



echo "</tr>";
}
echo"</table>";

?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center"><a href="admin.php" target="_parent">Superintendent panel <b>|</b></a>
			
			<a href="index.php" target="_parent">Log out</a></td>
		
          </tr>
          <tr>
            <td align='center' bgcolor='white' height='1'>
					2018 
                    
					BENGALURU PRISON SERVICES
            </td>
          </tr>
	</table>
</body>
</head>
</html>
