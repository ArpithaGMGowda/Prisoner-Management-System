<html>
<head>
  <title>View Guard  </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='#999999' valign='center'>
			
			


<?php

$searchTerm = trim($_GET["keyname"]);

//check whether the name parsed is empty
if($searchTerm == "")
{
	echo "Enter name you are searching for.";
	exit();
}

$host="localhost";
$username="root";
$password="root";
$db_name="ma";


$conn=mysqli_connect("$host","$username","$password","$db_name") or die("cannot connect");
mysqli_select_db($conn,"$db_name")or die("cannot connect");

$sel= "select * from guard WHERE gid='$searchTerm' order by name";
$result = mysqli_query($conn,$sel);

if(mysqli_num_rows($result) >= 1)
{
   while($row = mysqli_fetch_array ($result))
{
	echo"<table align='center' width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='green'>
<caption><h3>GUARD INFORMATION</h3></caption>
<tr bgcolor='blue'>
<tr bgcolor='silver'>
<th width='3%'>name</th>
<th width='15%'>address</th>
<th width='10%'>mobile_no</th>
<th width='10%'>email</th>
<th width='15%'>gender</th>
<th width='3%'>username</th>
<th width='15%'>password</th>
<th width='15%'>gid</th>
<th width='15%'>sid</th>
</tr>";
echo "<tr bgcolor='white'>";

echo  "<td width='3%'>".$row ['name']."</td>";
echo  "<td width='10%'>".$row ['address']."</td>";
echo  "<td width='10%'>".$row ['mobile_no']."</td>";
echo  "<td width='10%'>".$row ['email']. "</td>";
echo  "<td width='10%'>".$row ['gender']."</td>";
echo  "<td width='10%'>".$row ['username']."</td>";
echo  "<td width='10%'>".$row ['password']."</td>";
echo  "<td width='10%'>".$row ['gid']."</td>";
echo  "<td width='10%'>".$row ['sid']."</td>";
echo "</tr>";
}
echo"</table>";
echo "<br/>";
	echo "<br/>";	
}
else
{

	echo'<body bgcolor="grey">';
	echo'<center>';
	echo "<h2>No record found please check your ID </h2>";
	
	
	echo'</center>';
echo'</body>';
	 
}
?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center"><a href="admin.php" target="_parent"> [Superintendent panel] <b></b></a>
			<a href="index.php" target="_parent"> [Log out] </a></td>
		
          </tr>
          <tr>
            <td align='center' bgcolor='white' height='1'>
					
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					2018 BENGALURU PRISON SERVICES
            </td>
          </tr>
	</table>
</body>
</head>
</html>
