<html>
<head>
  <title>Guard update form</title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='white' valign='center'>


<?php


$host="localhost";
	   $user="root";
		$pass="root";
		$db="ma";
		$conn=mysqli_connect($host,$user,$pass,$db);
		$gid="";
		$name="";
$address="";
$gender="";
$mobile_no="";
$email="";
$username="";
$password="";
$gid="";
$sid="";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
	$conn=mysqli_connect($host,$user,$pass,$db);

}catch(MYSQLI_sql_Exception $ex){
	echo ("error error");
}
function getData(){
	$data=array();
	$data[0]=$_POST['gid'];
	$data[1]=$_POST['name'];
$data[2]=$_POST['address'];
$data[3]=$_POST['mobile_no'];
$data[4]=$_POST['email'];
$data[5]=$_POST['gender'];
$data[6]=$_POST['username'];

	return $data;
}
if(isset($_POST['update'])){
	$info=getData();
	$insert_query="update  guard set name='$info[1]',address='$info[2]',mobile_no='$info[3]',email='$info[4]',gender='$info[5]',
		  username='$info[6]' WHERE gid ='$info[0]'";

	try{
		//echo("hi");
		$insert_result=mysqli_query($conn,$insert_query);
			//echo("helo");
		if($insert_result){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}

}


?>
<html>
<head>
<script>

    }
}
</script>
<title>update form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table border="0" bgcolor="silver" align="center" width="54%">
<tr bgcolor="black">
<td align="center">
<font size="5">
<a href="admin.php">Home</a> 
</font>
</td>
</tr>
<tr>
<td>
<div>
		<center>
<form action="updateguard.php" method="post">
<table bgcolor="white" height="450" border="0" align="center" width="50%">
<b>GID:</b><input type="text" name="gid" placeholder="gid" value="<?php echo($gid);?>"><br><br>
<b>-------------------------------------</b><br><br>
	<b>Name:</b><input type="text" name="name" placeholder="name" value="<?php echo($name);?>"><br><br>
<b>Address:</b><input type="text" name="address" placeholder="address" value="<?php echo($address);?>"><br><br>
<b>Mobile_no:</b><input type="text" name="mobile_no" placeholder="mobile_no" value="<?php echo($mobile_no);?>"><br><br>
<b>Email:</b><input type="text" name="email" placeholder="email" value="<?php echo($email);?>"><br><br>
<b>gender:</b><input type="text" name="gender" placeholder="gender" value="<?php echo($gender);?>"><br><br>
<b>Username:</b><input type="text" name="username" placeholder="username" value="<?php echo($username);?>""><br><br><br><br><br><br>


<input type="submit" name="update" value="Add" />

</table>
</form>
</center>


<tr>
	<center>
<a href="guarddetails.php"><<<<<button>BACK</button><<<<</a></center>
	
<td height="21" colspan="2" align="center" bgcolor="silver">2018 BENGALURU PRISON SERVICES</td>
</body>
</html>
