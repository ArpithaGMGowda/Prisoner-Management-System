<html>
<head>
  <title>View Prisoners  </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='#999999' valign='center'>


<?php

$host="localhost";
$username="root";
$password="root";
$db_name="ma";

$conn=mysqli_connect("$host","$username","$password") or die("cannot connect");
mysqli_select_db($conn,"$db_name")or die("cannot connect");
/*function getData(){
	$data=array();
	$data[0]=$_POST['guid'];
	/*$data[1]=$_POST['name'];
	$data[2]=$_POST['address'];
	$data[3]=$_POST['date_of_admission'];
	
	return $data;
}
if(isset($_POST['search'])){
	$info=getData(); */
$sel= mysqli_query($conn,"select p.name,p.father_name,p.country,p.marital_status,p.date_of_admission,p.work_assigned,p.mobile_no,p.date_of_release,p.address,p.account_number,p.height,p.weight,p.known_work,p.education,p.sentence,p.section,p.pid,p.sid,p.guid,c.warrentno from prisoner as p , court as c where c.warrentno=p.wno order by date_of_admission");
echo"<table align='center' width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='green'>
<caption><h3>PRISONERS INFORMATION</h3></caption>
<tr bgcolor='silver'>
<th width='10%'>pid</th>
<th width='3%'>Name</th>
<th width='15%'>warrentno</th>
<th width='10%'>father_name</th>
<th width='10%'>country</th>
<th width='15%'>Address</th>
<th width='10%'>marital_Status</th>
<th width='15%'>account_number</th>
<th width='10%'>mobile_no</th>
<th width='10%'>section</th>
<th width='15%'>sentence</th>
<th width='3%'>Education</th>
<th width='15%'>height</th>
<th width='15%'>weight</th>
<th width='15%'>known_work</th>
<th width='15%'>work_assigned</th>
<th width='15%'>superdent added</th>
<th width='15%'>assigned guard</th>
<th width='15%'>date_of_admission</th>
<th width='15%'>date_of_release</th>


</tr>";

   while($row=mysqli_fetch_array ($sel))
{
echo "<tr bgcolor='white'>";

echo  "<td width='3%'>".$row ['pid']."</td>";
echo  "<td width='3%'>".$row ['name']."</td>";
echo  "<td width='7%'>".$row ['warrentno']."</td>";
echo  "<td width='10%'>".$row ['father_name']."</td>";
echo  "<td width='10%'>".$row ['country']. "</td>";
echo  "<td width='10%'>".$row ['address']."</td>";
echo  "<td width='3%'>" .$row ['marital_status']."</td>";
echo  "<td width='10%'>".$row ['account_number']."</td>";
echo  "<td width='10%'>".$row ['mobile_no']."</td>";
echo  "<td width='10%'>".$row ['section']. "</td>";
echo  "<td width='10%'>".$row ['sentence']."</td>";
echo  "<td width='10%'>".$row ['education']."</td>";
echo  "<td width='10%'>".$row ['height']."</td>";
echo  "<td width='10%'>".$row ['weight']."</td>";
echo  "<td width='10%'>".$row ['known_work']."</td>";
echo  "<td width='10%'>".$row ['work_assigned']."</td>";
echo  "<td width='10%'>".$row ['sid']."</td>";
echo  "<td width='10%'>".$row ['guid']."</td>";
echo  "<td width='10%'>".$row ['date_of_admission']."</td>";
echo  "<td width='10%'>".$row ['date_of_release']."</td>";

echo "</tr>";
}
echo"</table>";

?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center"><a href="guard.php" target="_parent"> [Guard Panel] <b></b></a>
			<a href='total.php' target="_parent"> [total_prisoner] </a>
			<a href="viewfeedback.php" target="_parent"> [view Feedback] <b></b></a>
			<a href='mll.php' target="_parent"> [Log out] </a></td>
		
          </tr>
          <tr>
            <td align='center' bgcolor='white' height='1'>
					
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					2018 BENGALURU PRISON SERVICES
            </td>
          </tr>
	</table>
</body>
</head>
</html>
