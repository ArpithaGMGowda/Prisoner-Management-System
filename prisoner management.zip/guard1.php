<?php
$host="localhost";
		$user="root";
		$pass="root";
		$db="ma";
		$conn=mysqli_connect($host,$user,$pass,$db);
		$name="";
$address="";
$gender="";
$mobile_no="";
$email="";
$username="";
$password="";
$gid="";
$sid="";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
	$conn=mysqli_connect($host,$user,$pass,$db);

}catch(MYSQLI_sql_Exception $ex){
	echo ("error error");
}
function getData(){
	$data=array();
	$data[0]=$_POST['name'];
$data[1]=$_POST['address'];
$data[2]=$_POST['mobile_no'];
$data[3]=$_POST['email'];
$data[4]=$_POST['gender'];

$data[5]=$_POST['username'];
$data [6]=$_POST['password'];
$data[7]=$_POST['gid'];
$data[8]=$_POST['sid'];
	return $data;
}
if(isset($_POST['Insert'])){
	$info=getData();
	$insert_query="INSERT INTO `guard`(`name`, `address`, `mobile_no`, `email`, `gender`, `username`, `password`, `gid`, `sid`) VALUES ('$info[0]','$info[1]','$info[2]','$info[3]','$info[4]','$info[5]','$info[6]','$info[7]','$info[8]')";

	try{
		//echo("hi");
		$insert_result=mysqli_query($conn,$insert_query);
			//echo("helo");
		if($insert_result){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}
$insert_query1="INSERT INTO `guard`(`name`, `address`, `mobile_no`, `email`, `gender`, `username`, `password`, `gid`, `sid`) VALUES ('$info[0]','$info[1]','$info[2]','$info[3]','$info[4]','$info[5]','$info[6]','$info[7]','$info[8]')";

	try{
		//echo("hi");
		$insert_result1=mysqli_query($conn,$insert_query1);
			//echo("helo");
		if($insert_result1){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}
}


?>
<html>
<head>
<script>

    }
}
</script>
<title>registration  form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table border="0" bgcolor="silver" align="center" width="54%">
<tr bgcolor="black">
<td align="center">
<font size="5">
<a href="admin.php">Home</a> 
</font>
</td>
</tr>
<tr>
<td>
<div>
		<center>
<form action="guard1.php" method="post">
<table bgcolor="white" height="450" border="0" align="center" width="50%">
	<b>name:</b><input type="text" name="name" placeholder="name" value="<?php echo($name);?>"><br><br>
<b>address:</b><input type="text" name="address" placeholder="address" value="<?php echo($address);?>"><br><br>
<b>gender:</b><input type="text" name="gender" placeholder="gender" value="<?php echo($gender);?>"><br><br>
<b>mobile_no:</b><input type="text" name="mobile_no" placeholder="mobile_no" value="<?php echo($mobile_no);?>"><br><br>
<b>email:</b><input type="text" name="email" placeholder="email" value="<?php echo($email);?>"><br><br>
<b>username:</b><input type="text" name="username" placeholder="username" value="<?php echo($username);?>""><br><br>
<b>password:</b><input type="text" name="password" placeholder="password" value="<?php echo($password);?>"><br><br>
<b>GID:</b><input type="text" name="gid" placeholder="gid" value="<?php echo($gid);?>"><br><br>

<b>SID:</b><input type="text" name="sid" placeholder="sid" value="<?php echo($sid);?>"><br><br>

<input type="submit" name="Insert" value="Add" />

</table>
</form>
</center>


<tr>
	<center>
<a href="admin.php"><<<<<button>BACK</button><<<<</a></center>
	
<td height="21" colspan="2" align="center" bgcolor="silver">2018 BENGALURU PRISON SERVICES</td>
</body>
</html>
