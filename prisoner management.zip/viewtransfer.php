<html>
<head>
  <title>View transfer record  </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='#999999' valign='center'>

<?php

$host="localhost";
$username="root";
$password="root";
$db_name="ma";
$tbl_name="transfed_to,prisoner";

$con=mysqli_connect("$host","$username","$password","$db_name") or die("cannot connect" .mysqli_error($con));
mysqli_select_db($con,"$db_name")or die("cannot connect");

$sel= mysqli_query($con, "select name,from_prison,to_prison,reason,transfer_id,pno from prisoner,transfer_to where pno=pid");
echo"<table align='center' width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='green'>
<caption><h3>PRISONER TRANSFER  INFORMATION</h3></caption>
<tr bgcolor='silver'>
<th width='3%'>Prisoner name</th>
<th width='10%'>from_prison</th>
<th width='15%'>transfered_to</th>
<th width='10%'>reason</th>
<th width='10%'>transfer_id</th>
<th width='10%'>pid</th>
</tr>";

   while($row=mysqli_fetch_array ($sel))
{
echo "<tr bgcolor='white'>";

echo  "<td width='3%'>".$row ['name']."</td>";
echo  "<td width='10%'>".$row ['from_prison']."</td>";
echo  "<td width='7%'>".$row ['to_prison']."</td>";
echo  "<td width='10%'>".$row ['reason']. "</td>";
echo  "<td width='10%'>".$row ['transfer_id']."</td>";
echo  "<td width='10%'>".$row ['pno']. "</td>";

echo "</tr>";
}
echo"</table>";

?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center"><a href="admin.php" target="_parent">Superintendent Panel <b>|</b></a>
			
			<a href="index.php" target="_parent">Log out</a></td>
		
          </tr>
          <tr>
            <td align='center' bgcolor='white' height='1'>
					 2018
                    
					BENGALURU PRISONS SERVICE
            </td>
          </tr>
	</table>
</body>
</head>
</html>
