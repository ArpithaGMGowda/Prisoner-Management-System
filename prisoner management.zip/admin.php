<?php

?>

</html>
<?php 

session_start();

if(!$_SESSION['ma'])
{
header('location:index.php');

}
	
?>

<html>
<head>
  
  <title>Banglore PRISONS SERVICE</title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='100' cellpadding='10' cellspacing='0' height='625'>
          
		  <tr>
            <td colspan='3' height='2'><img src='prison3.jpg' width='800' height='100'></t>
          </tr>
		  <tr>
            <td colspan="7" bgcolor="silver" height="1" align="center">
		      <h1><font size="5">
	           
		        <a href="search-by-id.php"> [Search Prisoner]  </a> 
				<a href="id-by-guard.php"> [Search guard]  </a> 
		        <a href="complain.php"> [Feedback]  </a>
				 <a href="ptransfer.php"> [Prisoner Transfer]  </a> 
		        <a href="guard1.php"> [Add Guard]  </a>
			<a href="prisoner1.php"> [Add prisoner] </a>
		   <a href="remissiondisplay.php"> [Remission display] </a>   
				<a href="remission.php"> [Remission] </a>
	<a href="viewuser.php"></a>
		        </font></h1>
            </td>
			 </td>
		 
            <td height='1' colspan='3' align='right' bgcolor="black">&nbsp;</td>
			
          </tr>
		 
          <tr>
		 
            <td width='4%' bgcolor='#FFFFFF' valign='top'>
<h3 align='center'  title='You should be online'>&nbsp;</h3></td>

            <td width='71%' valign='top' bgcolor="#FFFFFF">

<p align='center'>
 

<h3 align='center'>&nbsp;</h3>
<br/>
<h3 align='center'>ABOUT BENGALURU PRISON SYSTEM </h3>
<P align='justify'><font face='Times new roman, Helvetica, sans-serif'>This system enables the Superintendent to provide services to users and the he can add and upload information, update, delete, view the record(s) added. The administrator can also change his account for more security.</font></p>

		<br>
			</td>
            <td width='25%' bgcolor='black'  valign='top'>
			
	
<table border='0' align='center'>
<tr>
<td width="452" bgcolor="black">
<h3>  Admin Management : </h3><br/>


<ul>
	
	<li><a href='guarddetails.php'><b>Guard Details</b></a></li>
		<br>

	<li><a href='viewprisoners.php'><b>Prisoners Information Display</b></a></li>
		<br>
		<li><a href='viewcase.php'><b>Case Information View</b></a></li>
		<br>
	<li><a href='viewtransfer.php'><b>Prisoners Transfer Information</b></a></li>
		<br>
	<li><a href='viewannounce.php'><b>View Comment</b></a></li>
		<br>
    <li><a href='index.php''><b>LOG OUT</b></a></li>
</ul>
</td>
</tr>
</table>


			
			</td>
          </tr>
          <tr>
            <td colspan='3' align='center' bgcolor='silver' height='1'>
					 <strong>
                2018 BENGALURU PRISON SERVICES</strong></td>
          </tr>
	</table>
</body>
</head>
</html>
