<html>
<head>
  <title>BANGALORE PRISONS SERVICE</title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='silver' width='820' cellpadding='10' cellspacing='0' height='325'>
          
		  <tr>
            <td colspan='3' height='2'><img src='prison3.jpg'></td>
          </tr>
		  <tr>
            <td colspan="7" bgcolor="silver" height="1" align="center">
		      <h1><font size="5">
	           <a href="index.php"> [Home] </a> 
              			   
		      
            </td>
			 </td>
		 
            <td height='1' colspan='3' align='right' bgcolor="silver"></td>
			
          </tr>
		 
          <tr>
		 
            <td width='4%' bgcolor='silver' valign='top'>
<h3 align='center'  title='You should be online'></h3></td>

            <td width='11%' valign='top' bgcolor="white">

<p align='center'>
<br/>
<h3 align='center'>ABOUT Banglore PRISON SYSTEM </h3>
<P align='justify'><font face='Times new roman, Helvetica, sans-serif'><br>Message from Administrator</br>

<br>Along the course of 15 years Prisoner Management in Bangalore has gone a long way. The latest approach to prisoner management is considered to be the best among all these progress. From registering all prisoners one by one tediously using old school methods to computerized which made management and alot of people job made easier. Even though alot of things have changed the rehabilitation method for our prisoners are still top notch and we promise to keep it that way.</br>
<br>For any queries please contact Arpitha,Brunda,Mala,Nikhilesh</br> 

</font></p>

		<br> 


<br/>
<!--
<div id="content">
    	<div id="gallerycontainer">
	<div class="portfolio-area" style="margin:0 auto; padding:50px 20px 20px 20px; width:720px;">	
		<iframe width="100%" height="50" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src=""></iframe><br /><small><a href="https://maps.google.com.ph/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Florida+Bus+Terminal,+West+Kamias,+Quezon+City,+Metro+Manila&amp;aq=0&amp;oq=floridBarangay+West+Kamias,+Cubao,+Quezon+City,+Metro+Manila&amp;sll=14.630676,121.047814&amp;sspn=0.011772,0.021136&amp;t=h&amp;ie=UTF8&amp;hq=&amp;hnear=Florida+Bus+Terminal,+Quezon+City,+Metro+Manila&amp;ll=14.630676,121.047814&amp;spn=0.011772,0.021136&amp;z=14" style="color:#0000FF;text-align:left"></a></small>
				<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>
-->
	



	
	
		    
</ul>
</td>
</tr>
</table>
			</td>
          </tr>
          <tr>
            <td colspan='3' align='center' bgcolor='#FF0000' height='1'>
					 <strong>
						<center>BENGALURU PRISONS SERVICE BY RVCE</strong></td></center>
          </tr>
	</table>
</body>
</head>
</html>

