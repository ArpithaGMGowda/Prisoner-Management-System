<!DOCTYPE>
<html>
<head>
   
  <title>Banglore Prisons Service </title>
  <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align="center" border="0" bgcolor="silver" width="840" cellpadding="8" cellspacing="0" height="421">
          <tr><center>
            <td colspan="0" height="1"><img src="prisonpic.jpg" width="800" height="300"></td>
			</center>
          </tr>
          <tr>
            <td colspan="5" bgcolor="silver" height="1" align="center">
		      <h1><font size="5">
	             	 
		        <a href="mll.php"> [Member Login] </a>  
		        <a href="au.php"> [About Us] </a>
		        
		        </font></h1>
            </td>
</tr>
<td width="91%" height="387" valign="top" bgcolor="white"><h2> Banglore Prisons Service</h2>
  <p>The Introduction of computer and database has brought many changes to various fields, such as Sports, health and in business sector generally. </p>
  <p>Just because it helps to carry out complex and lengthy analytical operation very rapidly to effective communication system, it is also time saving, versatile, flexible storage of large information and reduce human labor.</p>
  <p>Prisoner management system is the collection of register cases for each prisoner entering the prison and also the Guards of each prisoner and also head of the prison - Superintendent. </p>
  <p><strong>A good system for prison service should be automated</strong></p>
    <div><img src="prison.jpg" width="200" height="170"  alt=""/><img src="jail11.jpg" width="310" height="177"  alt=""/><img src="Prison1.jpg" width="200" height="178"  alt=""/></div></td>

<td width="30%" height="387" valign="top" bgcolor="#FFFFFF">
</td>
<td bgcolor="#FFFFFF"></td>
<td width="30%" bgcolor="#FFFFFF">

<tr>
<td bgcolor="silver" colspan="3" align="center"><strong>
 2018 BANGALORE PRISON SERVICES</strong></td>
</tr>
</table>
</body>
</html>
</body>
</html>
