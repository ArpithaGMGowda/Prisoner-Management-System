<html>
<head>
  <title>total Prisoners  </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='#999999' valign='center'>


<?php

$host="localhost";
$username="root";
$password="root";
$db_name="ma";

$conn=mysqli_connect("$host","$username","$password") or die("cannot connect");
mysqli_select_db($conn,"$db_name")or die("cannot connect");

$sel= mysqli_query($conn,"select count(*) from prisoner");
echo"<table align='center' width='10%' border='0' cellpadding='3' cellspacing='2' bgcolor='green'>
<caption><h5>TOTAL PRISONER IS</h5></caption>
<tr bgcolor='silver'>
<th width='15%'>TOTAL PRISONER</th>




</tr>";

   while($row=mysqli_fetch_array ($sel))
{
echo "<tr bgcolor='white'>";

echo  "<td width='3%'>" .$row ['count(*)']."</td>";


echo "</tr>";
}
echo"</table>";

?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center"><a href="guard.php" target="_parent"> [Guard Panel] <b></b></a>
			<a href='index.php' target="_parent"> [Log out] </a></td>
		
          </tr>
          <tr>
            <td align='center' bgcolor='white' height='1'>
					
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					2018 BENGALURU PRISON SERVICES
            </td>
          </tr>
	</table>
</body>
</head>
</html>
