<html>
<head>
  <title>View Prisoners  </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='#999999' valign='center'>


<?php

$host="localhost";
$username="root";
$password="root";
$db_name="ma";

$conn=mysqli_connect("$host","$username","$password") or die("cannot connect");
mysqli_select_db($conn,"$db_name")or die("cannot connect");
$sel= mysqli_query($conn,"select name,address,country,father_name,gender,marital_status,age,section,sentence,date_of_admission,date_of_release,mobile_no,account_number,height,weight,known_work,work_assigned,identification,time,education,pid,wno,sid,guid from prisoner where (pid NOT IN (select pno from transfer_to))");
echo"<table align='center' width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='green'>
<caption><h3>PRISONER INFORMATION</h3></caption>
<tr bgcolor='silver'>
<th width='10%'>pid</th>
<th width='3%'>Name</th>
<th width='15%'>warrentno</th>
<th width='10%'>father_name</th>
<th width='10%'>country</th>
<th width='15%'>Address</th>
<th width='10%'>marital_Status</th>
<th width='15%'>account_number</th>
<th width='10%'>mobile_no</th>
<th width='10%'>section</th>
<th width='15%'>sentence</th>
<th width='3%'>Education</th>
<th width='15%'>height</th>
<th width='15%'>weight</th>
<th width='15%'>known_work</th>
<th width='15%'>work_assigned</th>
<th width='15%'>superdent added</th>
<th width='15%'>assigned guard</th>
<th width='15%'>date_of_admission</th>
<th width='15%'>date_of_release</th>


</tr>";

   while($row=mysqli_fetch_array ($sel))
{
echo "<tr bgcolor='white'>";

echo  "<td width='3%'>".$row ['pid']."</td>";
echo  "<td width='3%'>".$row ['name']."</td>";
echo  "<td width='7%'>".$row ['wno']."</td>";
echo  "<td width='10%'>".$row ['father_name']."</td>";
echo  "<td width='10%'>".$row ['country']. "</td>";
echo  "<td width='10%'>".$row ['address']."</td>";
echo  "<td width='3%'>" .$row ['marital_status']."</td>";
echo  "<td width='10%'>".$row ['account_number']."</td>";
echo  "<td width='10%'>".$row ['mobile_no']."</td>";
echo  "<td width='10%'>".$row ['section']. "</td>";
echo  "<td width='10%'>".$row ['sentence']."</td>";
echo  "<td width='10%'>".$row ['education']."</td>";
echo  "<td width='10%'>".$row ['height']."</td>";
echo  "<td width='10%'>".$row ['weight']."</td>";
echo  "<td width='10%'>".$row ['known_work']."</td>";
echo  "<td width='10%'>".$row ['work_assigned']."</td>";
echo  "<td width='10%'>".$row ['sid']."</td>";
echo  "<td width='10%'>".$row ['guid']."</td>";
echo  "<td width='10%'>".$row ['date_of_admission']."</td>";
echo  "<td width='10%'>".$row ['date_of_release']."</td>";

echo "</tr>";
}
echo"</table>";

?>

<br/>
			</td>
          </tr>
          <tr>
		  
			<td>
			<center><a href="admin.php" target="_parent"> [admin Panel] <b></b></a>
		  <a href="total1.php" target="_parent"> [current prisoner count] <b></b></a>
		  		  <a href="updateprisoner.php" target="_parent"> [update prisoner details] <b></b></a>
			<a href='mll.php' target="_parent"> [Log out] </a></center>
        </td>
		  </tr>
          <tr>
            <td align='center' bgcolor='white' height='1'>
					
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					2018 BENGALURU PRISON SERVICES
            </td>
          </tr>
	</table>
</body>
</head>
</html>
