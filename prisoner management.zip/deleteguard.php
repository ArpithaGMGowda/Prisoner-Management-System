<html>
<head>
  <title>Delete Guard</title>
  <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
        
          <tr>
            <td colspan="3" bgcolor='#999999' valign='center'>

<?php
ob_start();
$link=mysqli_connect("localhost","root","root");
mysqli_select_db($link,"ma");
$result=mysqli_query($link,"select * from guard");
?>


<?php

//To delete:
if(isset($_POST["delete"])){
$gid=$_POST["gid"];
$delete=mysqli_query($link,"delete from guard where gid='$_POST[gid]'");
if($delete){
print "<script language=\"javascript\">
	alert(\"Successfully deleted!...\")
	location.href=\"deleteguard.php\"
	</script>";
}
else{
print "<script language=\"javascript\">
	alert(\"Not deleted!...\")
	location.href=\"deleteguard.php\"
	</script>";
}
}
?>



<?php

echo "<table width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='black'>
<caption><b>DELETE GUARD RECORD</b></caption>
<tr bgcolor='silver'>
<th width='7%'>SL.no</th>
<th width='7%'>GID</th>
<th width='10%'>Name</th>
<th width='10%'>Address</th>
<th width='10%'>Email</th>
<th width='15%'>mobile_no</th>

<th width='10%'>Gender</th>



</tr>";
$i=1;
while($row=mysqli_fetch_array($result)){
echo "<form method=POST>";
echo "<tr bgcolor='white'>
<td>$i<input type=\"hidden\" name=\"gid\" value=\"$row[gid]\"></td>
<td>$row[gid]</td>
<td>$row[name]</td>
<td>$row[address]</td>
<td>$row[email]</td>
<td>$row[mobile_no]</td>

<td>$row[gender]</td>
<td align='center'><input type=submit name=delete value=delete></td>
</tr>";
echo "</form>";
$i++;
}
echo "</table>";
?>

<br/>

			</td>
          </tr>
          <tr>
		  <td align="center"><a href="admin.php" target="_parent"> [superintendent Panel ] <b></b></a>
			<a href="guarddetails.php" target="_parent"> [View Guard(s)] <b></b></a>
			<a href='../index.php' target="_parent"> [Log out] </a></td>
		
          </tr>
          <tr>
            <td colspan='3' align='center' bgcolor='silver' height='1'>
					
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					BANGALORE PRISONS SERVICE
            </td>
          </tr>
	</table>
</body>
</head>
</html>

