<?php
$host="localhost";
		$user="root";
		$pass="";
		$db="ma";
		$conn=mysqli_connect($host,$user,$pass,$db);
		$subject="";
		$message="";
		/*$feedback_id="";*/
		$pno="";
		$guid="";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
	$conn=mysqli_connect($host,$user,$pass,$db);

}catch(MYSQLI_sql_Exception $ex){
	
}
function getData(){
	$data=array();
	$data[0]=$_POST['subject'];
	$data[1]=$_POST['message'];
	/*$data[2]=$_POST['feedback_id'];*/
	$data[3]=$_POST['pno'];
	$data[4]=$_POST['guid'];
	return $data;
}
if(isset($_POST['Insert'])){
	$info=getData();
	$insert_query="INSERT INTO `feedbackby_guard`(`subject`, `message`, `pno`, `guid`)VALUES ('$info[0]','$info[1]','$info[3]','$info[4]')";

	try{
		//echo("hi");
		$insert_result=mysqli_query($conn,$insert_query);
			//echo("helo");
		if($insert_result){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}

}


?>
<html>
<head>
<title> Transfer Form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table width="100%" height="91" border="0" align="center" bgcolor="silver">
<tr>
<td height="33" align="center" bgcolor="black">
<font size="5">
<a href="guard.php">Guard panel</a> 
</font>
</td>
</tr>
<td height="5"><tr>
<td>
<h4 style="color:black;" align="center">
	Feedback entry<br>
-----------------------------------------------
</h4>
<div>
	<center>
	
<form action="gfeedback.php" method="post">
		<ul>
		<b>Subject:			</b><input type ="text" name="subject" placeholder="subject" value="<?php echo($subject);?>"><br><br>
		
		<b>Message:			</b><input type ="text" name="message" placeholder="message" value="<?php echo($message);?>"><br><br>
		
		<!--<b>Feedback_id:		</b><input type ="number" name="feedback_id" placeholder="feedback_id" value="/"><br><br>-->
		<b>Prisoner ID:		</b><input type ="number" name="pno" placeholder="pno" value="<?php echo($pno);?>"><br><br>
		<b>Guard ID:		</b><input type ="number" name="guid" placeholder="guid" value="<?php echo($guid);?>"><br><br>
		</ul>
    <br>
  
 </tr>
 <td align="center"><input type="submit" name="Insert" value="Add" /></td>
</table>
</form>

</center>


<tr>
	<center>
<a href="guard.php"><<<<<button>BACK</button><<<<</a></center>
<br>
<center><td height="21" colspan="2" align="center" bgcolor="silver"><strong> 2018 BENGALURU PRISON SERVICES</strong></td></center>
</tr>
</td>
</div>
</table>
</body>
</html>
