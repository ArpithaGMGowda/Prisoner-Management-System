<?php
?>

</html>
<?php
if($_POST)
{
	$host="localhost";
	$user="root";
	$pass="root";
	$db="ma";
	$username=$_POST['username'];
	$password=$_POST['password'];

	$conn=mysqli_connect($host,$user,$pass,$db);
	$query="select * from superintendent where username='$username' and password='$password'";
	$result=mysqli_query($conn,$query);
	$query1="select * from guard where userName='$username' and password='$password'";
	$result1=mysqli_query($conn,$query1);
	if(mysqli_num_rows($result)==1){
		session_start();
		$_SESSION['ma']='true';
		$_SESSION['username']='$username';
		$_SESSION['password']='$password';

			header('location:admin.php');
	}
	else if(mysqli_num_rows($result1)==1){
		session_start();
		$_SESSION['ma']='true';
		$_SESSION['username']='$username';
		$_SESSION['password']='$password';

			header('location:guard.php');
		}
	else{
			$mess="wrong username and password";
			echo "<script type='text/javascript'>alert('$mess');</script>";
		}}
		
?>
</body>
  <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
  <table align="center" border="0" bgcolor="silver" width="540" cellpadding="9" cellspacing="0" height="525">
          <tr>
            <td colspan="3" height="2"><img src="prison3.jpg" width="860"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="black" height="1" align="center">
    <font size="4">
         <a href="index.php">HOME</a>  
      
          </font>
            </td>
          </tr>
          <tr>
            <td width="25%" bgcolor="#FFFFFF" ><img src="Login.png" width="271" height="252"  alt=""/></td>
            <td width="50%" align="center" bgcolor="#FFFFFF">



<div class="ex">

<form action="mll.php" method="post">
<table width="408" height="142" border="0" bgcolor="silver">
	    <h2><b>LOGIN MEMBERS </b></h2>

<tr>
<td height="36" bgcolor="#FFFFFF"><b>User Name:</b></td>
<td height="36" bgcolor="#FFFFFF"><input type="text" name="username" /></td>
</tr>

<tr>
<td height="36" bgcolor="#FFFFFF"><b>Password:</b></td>
<td height="36" bgcolor="#FFFFFF"><input type="password" name="password" />
<input type="submit" value="LOGIN" /></td>
</tr>
<!--<tr><td bgcolor="#FFFFFF"><b>Select User:</b></td>
       <td height="36" bgcolor="#FFFFFF"> <select name="cmbUser">
		 <option>Guard</option>
           <option>Superintendent</option></td></tr>
<td height="36" bgcolor="#FFFFFF" align="center">-->
	</td>
</form>
</td>
</tr>
<tr>
<td height="38" colspan="3" align="center" bgcolor="white">2018 BENGALURU PRISON SERVICES</td>
</tr>
</table>
</body>
</html>

