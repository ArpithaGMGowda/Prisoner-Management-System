<html>
<head>
  <title>View Remission  </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='#999999' valign='center'>

<?php

$host="localhost";
$username="root";
$password="root";
$db_name="ma";
$tbl_name1="prisoner,remission";
//$tbl_name2="prisoner";

$conn=mysqli_connect("$host","$username","$password") or die("cannot connect");
mysqli_select_db($conn,"$db_name")or die("cannot connect");

$sel= mysqli_query($conn,"select distinct  p.name,g.pno,r.fb_id,r.old_sentence,r.decrease_punishment,p.date_of_release from prisoner AS p,remission AS r,feedbackby_sup AS f,feedbackby_guard AS g where g.feedback_id=f.fb_id AND p.pid=g.pno");
echo"<table align='center' width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='green'>
<caption><h3>GUARD INFORMATION</h3></caption>
<tr bgcolor='silver'>
<th width='7%'>Name</th>
<th width='10%'>Prisoner ID</th>
<th width='10%'>Old Sentence</th>
<th width='15%'>Decreased Punishment</th>
<th width='10%'>Date of Release</th>

</tr>";

   while($row=mysqli_fetch_array ($sel))
{
echo "<tr bgcolor='white'>";

echo  "<td width='7%'>".$row ['name']."</td>";
echo  "<td width='7%'>".$row ['pno']."</td>";
echo  "<td width='10%'>".$row ['old_sentence']."</td>";
echo  "<td width='10%'>".$row ['decrease_punishment']."</td>";
echo  "<td width='10%'>".$row ['date_of_release']."</td>";



echo "</tr>";
}
echo"</table>";

?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center"><a href="admin.php" target="_parent"> [superintendent Page] <b></b></a>
			
			<a href="index.php" target="_parent"> [Log out] </a></td>
		
          </tr>
          <tr>
            <td align='center' bgcolor='white' height='1'>
					
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					BANGLORE PRISONS SERVICE
            </td>
          </tr>
	</table>
</body>
</head>
</html>
