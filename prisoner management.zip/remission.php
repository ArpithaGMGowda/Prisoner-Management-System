<?php
$host="localhost";
		$user="root";
		$pass="root";
		$db="ma";
		$conn=mysqli_connect($host,$user,$pass,$db);

		$old_sentence="";
		$decrease_punishment="";
		$date="";
		$fb_id="";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
	$conn=mysqli_connect($host,$user,$pass,$db);

}catch(MYSQLI_sql_Exception $ex){
	echo ("error error");
}
function getData(){
	$data=array();
$data[0]=$_POST['old_sentence'];
$data[1]=$_POST['decrease_punishment'];
$data[2]=$_POST['date'];
$data[3]=$_POST['fb_id'];

	return $data;
}
if(isset($_POST['Insert'])){
	$info=getData();
	$insert_query="INSERT INTO `remission`(`old_sentence`, `decrease_punishment`, `date`, `fb_id`) VALUES ('$info[0]','$info[1]','$info[2]','$info[3]')";

	try{
		//echo("hi");
		$insert_result=mysqli_query($conn,$insert_query);
			//echo("helo");
		if($insert_result){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}

	$insert_query="update prisoner,remission,feedbackby_guard,feedbackby_sup set 				prisoner.date_of_release=DATE_SUB(date_of_release,INTERVAL '$info[1]' DAY) 				where '$info[3]'=feedbackby_sup.fb_id and feedbackby_guard.feedback_id=feedbackby_sup.fb_id and feedbackby_guard.pno=prisoner.pid";

		  

	try{
		//echo("hi");
		$insert_result=mysqli_query($conn,$insert_query);
			//echo("helo");
		if($insert_result){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data update successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data updated";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}







}
?>
<html>
<head>
<title>Remission form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<center>
<table border="0" bgcolor="silver" align="center" width="84%">
<tr bgcolor="black">
<td align="center">
<font size="5">
<a href="admin.php">Home</a> 
</font>
</td>
</tr>
<tr>
<td>
<center>
<form action="remission.php" method="post">
<table bgcolor="white" height="431" border="0" align="center" width="50%">
<b>OLD SENTENCE:</b><input type="text" name="old_sentence" placeholder="old_sentence" value="<?php echo($old_sentence);?>"><br><br>
<b>DECREASE SENTENCE:</b><input type="text" name="decrease_punishment" placeholder="decrease_punishment" value="<?php echo($decrease_punishment);?>"><br><br>
<b>DATE:</b><input type="date" name="date" placeholder="date" value="<?php echo($date);?>"><br><br>
<b>FBID:</b><input type="number" name="fb_id" placeholder="fb_id" value="<?php echo($fb_id);?>"><br><br>
 <input type="submit" name="Insert" value="Add" /></center>
 </tr>
</table>
</form>
<center>
 
</tr>

<tr>
</tr>
</table>
	<td><center>
<a href="admin.php"><<<<<button>BACK</button><<<<</a></center></td></center>
</td><br/><br/>
</body>
<center>
<td height="21" colspan="2" bgcolor="silver">2018 BENGALURU PRISON SERVICES</td>
</center>
</tr>
</table>
</body>
</html>
