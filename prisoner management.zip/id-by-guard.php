<html>
<head>
  
  <title>PRISONER details</title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table align="center" border="0" bgcolor="silver" width="1004" cellpadding="8" cellspacing="0" height="515">
          <tr>
            <td colspan="0" height="246"><img src="Prison1.jpg" width="1045" height="230"></td>
          </tr>
          <tr>
            <td colspan="8" bgcolor="black" height="3" align="center">
			
			
		<font size="5">  
		 
         <a href="admin.php"> [Superintendent Panel] </a>
          </font>
            </td>
</tr>
<td align="center" bgcolor="#FFFFFF"><h1> Seacrh By Guard ID</h1>
        <form action="search-guard.php" method="get">
		<label>ID:
         <input type="text" name="keyname" #full/> 
		 </label>
          <input type="submit"  a href="search-prisoner.php"/>
		  
		  <a>
      </form>
     <td height="191" bgcolor="#FFFFFF"></td>
<td width="7%" bgcolor="#FFFFFF"></td>
<td width="2%" bgcolor="#FFFFFF">

<tr>
<td bgcolor="silver" colspan="3" align="center">
 2018 BENGALURU PRISON SERVICES</td>
</tr>
</table>
</body>
</html>
