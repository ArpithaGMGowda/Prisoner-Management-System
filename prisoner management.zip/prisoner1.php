<?php
$host="localhost";
		$user="root";
		$pass="root";
		$db="ma";
		$conn=mysqli_connect($host,$user,$pass,$db);
$name="";
$address="";
$country="";
$father_name="";
$gender="";
$marital_status="";
$age="";
$section="";
$sentence="";
$date_of_admission="";
$date_of_release="";
$mobile_no="";
$accountnumber="";
$height="";
$weight="";
$known_work="";
$workassigned="";
$identification="";
$time="";
$education="";
$pid="";
$wno="";
$sid="";
$guid="";


mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
	$conn=mysqli_connect($host,$user,$pass,$db);

}catch(MYSQLI_sql_Exception $ex){
	echo ("error error");
}
function getData(){
	$data=array();
$data[0]=$_POST['name'];
$data[1]=$_POST['address'];
$data[2]=$_POST['country'];
$data[3]=$_POST['father_name'];
$data[4]=$_POST['gender'];
$data[5]=$_POST['marital_status'];
$data[6]=$_POST['age'];
$data[7]=$_POST['section'];
$data[8]=$_POST['sentence'];
$data[9]=$_POST['date_of_admission'];
$data[10]=$_POST['date_of_release'];
$data[11]=$_POST['mobile_no'];
$data[12]=$_POST['account_number'];
$data[13]=$_POST['height'];
$data[14]=$_POST['weight'];
$data[15]=$_POST['known_work'];
$data[16]=$_POST['work_assigned'];
$data[17]=$_POST['identification'];
$data[18]=$_POST['time'];
$data[19]=$_POST['education'];
$data[20]=$_POST['pid'];
$data[21]=$_POST['wno'];
$data[22]=$_POST['sid'];
$data[23]=$_POST['guid'];
	return $data;
}
if(isset($_POST['Insert'])){
	$info=getData();
	$insert_query="INSERT INTO `prisoner`(`name`, `address`, `country`, `father_name`, `gender`, `marital_status`, `age`, `section`, `sentence`, `date_of_admission`, `date_of_release`, `mobile_no`, `account_number`, `height`, `weight`, `known_work`, `work_assigned`, `identification`, `time`, `education`, `pid`, `wno`, `sid`, `guid`) VALUES ('$info[0]','$info[1]','$info[2]','$info[3]','$info[4]','$info[5]','$info[6]','$info[7]','$info[8]','$info[9]','$info[10]','$info[11]','$info[12]]','$info[13]','$info[14]','$info[15]','$info[16]','$info[17]','$info[18]','$info[19]','$info[20]','$info[21]','$info[22]','$info[23]')";

	try{
		//echo("hi");
		$insert_result=mysqli_query($conn,$insert_query);
			//echo("helo");
		if($insert_result){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}
}
?>
<html>
<head>
<script>

    }
}
</script>
<title>registration  form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table border="0" bgcolor="silver" align="center" width="54%">
<tr bgcolor="black">
<td align="center">
<font size="5">
<a href="admin.php">Home</a> 
</font>
</td>
</tr>
<tr>
<td>
	<div>
		<center>
			<form action="prisoner1.php" method="post">
	<b>name:</b><input type="text" name="name" placeholder="name" value="<?php echo($name);?>"><br><br>
	<b>address:</b><input type="text" name="address" placeholder="address" value="<?php echo($address);?>"><br><br>
	<b>country:</b><input type="text" name="country" placeholder="country" value="<?php echo($country);?>"><br><br>
<b>father_name:</b><input type="text" name="father_name" placeholder="father_name" value="<?php echo($father_name);?>"><br><br>
<b>gender:</b><input type="text" name="gender" placeholder="gender" value="<?php echo($gender);?>"><br><br>
<b>marital_status:</b><input type="text" name="marital_status" placeholder="marital_status" value="<?php echo($marital_status);?>"><br><br>
<b>age:</b><input type="text" name="age" placeholder="age" value="<?php echo($age);?>"><br><br>
<b>section:</b><input type="text" name="section" placeholder="section" value="<?php echo($section);?>"><br><br>
<b>sentence:</b><input type="number" name="sentence" placeholder="sentence" value="<?php echo($sentence);?>"><br><br>
<b>date_of_admission:</b><input type="text" name="date_of_admission" placeholder="date_of_admission" value="<?php echo($date_of_admission);?>"><br><br>

<b>date_of_release:</b><input type="text" name="date_of_release" placeholder="date_of_release" value="<?php echo($date_of_release);?>"><br><br>

<b>mobile_no:</b><input type="number" name="mobile_no" placeholder="mobile_no" value="<?php echo($mobile_no);?>"><br><br>
<b>accountnumber:</b><input type="number" name="account_number" placeholder="account_number" value="<?php echo($account_number);?>"><br><br>
<b>height:</b><input type="number" name="height" placeholder="height" value="<?php echo($height);?>"><br><br>
<b>weight:</b><input type="number" name="weight" placeholder="weight" value="<?php echo($weight);?>"><br><br>
<b>known_work:</b><input type="text" name="known_work" placeholder="known_work" value="<?php echo($known_work);?>"><br><br>
<b>workassigned:</b><input type="text" name="work_assigned" placeholder="work_assigned" value="<?php echo($work_assigned);?>""><br><br>
<b>identification:</b><input type="text" name="identification" placeholder="identification" value="<?php echo($identification);?>""><br><br>
<b>time:</b><input type="text" name="time" placeholder="time" value="<?php echo($time);?>"><br><br>
<b>education:</b><input type="text" name="education" placeholder="education" value="<?php echo($education);?>"><br><br>
<b>pid_number:</b><input type="text" name="pid" placeholder="pid" value="<?php echo($pid);?>"><br><br>
<b>wno:</b><input type="number" name="wno" placeholder="wno" value="<?php echo($wno);?>"><br><br>
<b>SID:</b><input type="number" name="sid" placeholder="sid" value="<?php echo($sid);?>"><br><br>
<b>GID:</b><input type="number" name="guid" placeholder="guid" value="<?php echo($guid);?>"><br><br>

<input type="submit" name="Insert" value="Add" />
 </tr>
</table>
</form>
</center>


<tr>
	<center>
<a href="admin.php"><<<<<button>BACK</button><<<<</a></center>
<td height="21" colspan="2" align="center" bgcolor="silver">2018 BENGALURU PRISON SERVICES</td>
</tr>
</td>
</div>
</table>
</body>
</html>
