

<head>
  <title>BANGLORE PRISON SERVICES</title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='820' cellpadding='10' cellspacing='0' height='315'>
          <tr>
            <td colspan='3' height='2'><img src='Prison1.jpg' width='700' height="250"></td>
          </tr>
          <tr>
            <td height='1' colspan='3' align='right' bgcolor="black">&nbsp;</td>
          </tr>
		 
          <tr>
            <td width='4%' bgcolor='#FFFFFF' valign='top'>
<h3 align='center'  title='You should be online'>&nbsp;</h3></td>

            <td width='71%' valign='top' bgcolor="#FFFFFF">

<p align='center'>

<h3 align='center'>&nbsp;</h3>
<br/>
<h3 align='center'>ABOUT BANGLORE PRISON SYSTEM </h3>
<P align='justify'><font face='Times new roman, Helvetica, sans-serif'> This login is for the Guard. The system enable the Guard to provide services to Prisoner and here the Guard can upload information, view the record added and can add the feedback about particular prisoner. The Guard can also change his account for more security.</font></p>

			</td>
            <td width='40%' bgcolor='#FFFFFF'  valign='top'>
			
	
<table border='0' align='center'>
<tr>
<td width="900" bgcolor="silver">
<h4> <br> GUARD MANAGEMENT : </br></h4><br/>

<ul>

	<li><a href='gusearch1.php'><b>VIEW PRISONER</b></a></li>
		<br>
	<li><a href='search-form.php'><b>PRISONER UNDER CONTROL</b></a></li>
		<br>
	<li><a href='gfeedback.php'><b>ADD FEEDBACK</b></a></li>
		<br>
    <li><a href='index.php'><b>LOG OUT</b></a></li>
</ul>
</td>
</tr>
</table>

			</td>
          </tr>
          <tr>
            <td colspan='3' align='center' bgcolor='silver' height='1'>
				<strong>
                2018 BENGALURU PRISON SERVICES</strong></td>
          </tr>
	</table>
</body>
</head>
</html>
