<?php
?> 

</html>
<?php 

session_start();

	
?>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" media="screen" href="login.css" >

<head>
<body>
<table align='center' border='0' bgcolor='grey' width='1020' cellpadding='10' cellspacing='0' height='725'>
          
		  <tr>
            <td colspan='3' height='2' width ='4'><img src='banner1.gif'></td>
          </tr>
		  <tr>
             
		 
          <tr>
		 
            <td width='4%' bgcolor='silver' valign='top'>
<h3 align='center'  title='You should be online'>&nbsp;</h3></td>

            <td width='71%' valign='top' bgcolor="silver">

<p align='center'>
 

<h3 align='center'>&nbsp;</h3>
<br/>
<h3 align='center'> Enter the ID of Guard </h3>
<P align='justify'><font face='Arial, Helvetica, sans-serif'>
	</body>

</head>

<?php
$host="localhost";
		$user="root";
		$pass="";
		$db="jail";
		$name="";
		$address="";
		$date_of_admission="";
		$pid="";


mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
	$conn=mysqli_connect($host,$user,$pass,$db);

}catch(MYSQLI_sql_Exception $ex){
	echo ("error error");
}
function getData(){
	$data=array();
	$data[0]=$_POST['guid'];
	$data[1]=$_POST['name'];
	$data[2]=$_POST['address'];
	$data[3]=$_POST['father_name'];
    	$data[4]=$_POST['section'];
     	$data[5]=$_POST['date_of_admission'];
     	$data[6]=$_POST['date_of_release'];
     	$data[7]=$_POST['education'];
     	$data[8]=$_POST['sentence'];
     	$data[9]=$_POST['pid'];
     	$data[10]=$_POST['wno']; 
	return $data;
}
echo("hi");
if(isset($_POST['search'])){
	$info=getData();
	$search_query="SELECT name,address,father_name,section,date_of_admission,date_of_release,education,sentence,pid,wno FROM `prisoner` WHERE guid='$info[0]'";
	$search_result=mysqli_query($conn,$search_query);
	if($search_result){
		if(mysqli_num_rows($search_result)){
			while($rows = mysqli_fetch_array($search_result))
			{
				$guid=$rows['guid'];
				$name=$rows['name'];
				$address=$rows['address'];
				$father_name=$rows['father_name'];
				$section=$rows['section'];
				$date_of_admission=$rows['date_of_admission'];
				$date_of_release=$rows['date_of_release'];
				$education=$rows['education'];
				$sentence=$rows['sentence'];
				$pid=$rows['pid'];
				$wno=$rows['wno'];
			}

		}else{
			echo("no data");
		}
	}else{
		echo("result error");
	}
}

?>
<html>
<head>
	<meta charset="utf-8">
</head>

<body>
	<br>
	<br>

	<center><form method = "post" action ="gusearch.php">
		<div >
 <div id="left"><p>
 	<br>
		<b>guid:</b><input type ="number" name="guid" placeholder="guid" value="<?php echo($guid);?>"><br><br>
 		<b>name:</b><input type ="text" name="name" placeholder="name" value="<?php echo($name);?>"><br><br>
		<b>address:</b><input type ="text" name="address" placeholder="address" value="<?php echo($address);?>"><br><br>
		<b>father_name:</b><input type ="text" name="father_name" placeholder="father_name" value="<?php echo($father_name);?>"><br><br>
		<b>section:</b><input type ="text" name="section" placeholder="section" value="<?php echo($section);?>"><br><br>
		<b>date_of_admission:</b><input type ="date" name="date_of_admission" placeholder="date_of_admission" value="<?php echo($date_of_admission);?>"><br><br>
		<b>date_of_release:</b><input type ="date" name="date_of_release" placeholder="date_of_release"value="<?php echo($date_of_release);?>"><br><br>
		<b>education:</b><input type ="text" name="education" placeholder="education" value="<?php echo($education);?>"><br><br>
		<b>sentence:</b><input type ="text" name="sentence" placeholder="sentence" value="<?php echo($sentence);?>"><br><br>
		<b>pid:</b><input type ="number" name="pid" placeholder="pid" value="<?php echo($pid);?>"><br><br>
		<b>wno:</b><input type ="number" name="wno" placeholder="wno" value="<?php echo($wno);?>"><br><br>


		
	</p></div>
	

</center>
	<center>		
	<input type="submit" name="search" value="Search..."><br><br>
</center>
</div>
<br>
</body>
</form>

<center>
<a href="guard.php"><<<<<button>BACK</button><<<<</a></center>
</centre>
</body>
</html>