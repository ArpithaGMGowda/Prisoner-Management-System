-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 30, 2018 at 04:12 PM
-- Server version: 5.5.54
-- PHP Version: 5.3.10-1ubuntu3.26

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ma`
--

-- --------------------------------------------------------

--
-- Table structure for table `court`
--

CREATE TABLE IF NOT EXISTS `court` (
  `court_name` varchar(20) NOT NULL,
  `court_location` varchar(20) NOT NULL,
  `warrentno` int(20) NOT NULL,
  `section` varchar(20) NOT NULL,
  `sentence` varchar(20) NOT NULL,
  `email` varchar(20) DEFAULT NULL,
  `date_of_trial` date NOT NULL,
  PRIMARY KEY (`warrentno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `court`
--

INSERT INTO `court` (`court_name`, `court_location`, `warrentno`, `section`, `sentence`, `email`, `date_of_trial`) VALUES
('District Court', 'Udupi', 101, 'section 420', '12 years', 'distcourt@ud.gov.in', '2011-08-12'),
('District Court', 'Manglore', 102, 'section 610', '8 years', 'distcourt@ml.gov.in', '2015-10-19'),
('Supreme Court', 'Delhi', 111, 'section 377', '25 years', 'supreme@india.gov.in', '1997-12-22'),
('High Court', 'Kerala', 222, 'section 420', '12 years', 'court@ker.gov.in', '1997-12-18'),
('High Court', 'Karnataka', 333, 'section 120', '20 years', 'court@kar.gov.in', '2000-07-24'),
('High Court', 'Tamilnadu', 444, 'section 120', '20 years', 'court@tn.gov.in', '2002-06-30'),
('Supreme Court', 'Delhi', 555, 'section 510', '10 years', 'supreme@india.gov.in', '2011-09-23'),
('District Court', 'Manglore', 666, 'section 110', '5 years', 'distcourt@ml.gov.in', '2005-06-15'),
('District Court', 'Udupi', 777, 'section 610', '8 years', 'distcourt@ud.gov.in', '2017-03-28'),
('Supreme Court', 'Delhi', 888, 'section 120', '20 years', 'supreme@india.gov.in', '2015-09-19'),
('District Court', 'Mysore', 999, 'section 401', '18 years', 'distcourt@my.gov.in', '2018-01-26');

-- --------------------------------------------------------

--
-- Table structure for table `feedbackby_guard`
--

CREATE TABLE IF NOT EXISTS `feedbackby_guard` (
  `subject` varchar(20) NOT NULL,
  `message` varchar(20) DEFAULT NULL,
  `feedback_id` int(20) NOT NULL AUTO_INCREMENT,
  `pno` int(20) NOT NULL,
  `guid` int(20) NOT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `guid` (`guid`),
  KEY `pno` (`pno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12353 ;

--
-- Dumping data for table `feedbackby_guard`
--

INSERT INTO `feedbackby_guard` (`subject`, `message`, `feedback_id`, `pno`, `guid`) VALUES
('Behaviour', 'Good', 1, 13, 3333),
('work', 'good keep it up', 2, 14, 5555),
('Behaviour', 'bad', 3, 16, 5555),
('work', 'technically strong', 4, 20, 4444),
('Behaviour', 'very good', 12351, 19, 2222),
('Behaviour', 'very good', 12352, 19, 2222);

-- --------------------------------------------------------

--
-- Table structure for table `feedbackby_sup`
--

CREATE TABLE IF NOT EXISTS `feedbackby_sup` (
  `subject1` varchar(20) NOT NULL,
  `message1` varchar(20) DEFAULT NULL,
  `fb_id` int(20) DEFAULT NULL,
  `sid` int(20) NOT NULL,
  `date` date DEFAULT NULL,
  KEY `sid` (`sid`),
  KEY `fb_id` (`fb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbackby_sup`
--

INSERT INTO `feedbackby_sup` (`subject1`, `message1`, `fb_id`, `sid`, `date`) VALUES
('Behaviour', 'bad', 3, 11, '2016-09-23'),
('charecter', 'helping natuure', 3, 11, '2014-09-12'),
('charecter', 'dedicated to work', 12352, 11, '2012-09-14'),
('charecter', 'innoscent', 12351, 11, '2014-09-13'),
('Behaviour', 'helping nature', 3, 11, '2012-09-17'),
('character', 'best', 4, 11, '2012-09-15'),
('', '', 4, 11, '2018-04-30'),
('', '', 4, 11, '2018-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `guard`
--

CREATE TABLE IF NOT EXISTS `guard` (
  `name` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `mobile_no` int(10) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `gid` int(15) NOT NULL,
  `sid` int(15) DEFAULT NULL,
  PRIMARY KEY (`gid`),
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guard`
--

INSERT INTO `guard` (`name`, `address`, `mobile_no`, `email`, `gender`, `username`, `password`, `gid`, `sid`) VALUES
('p c ghose', 'andhra pradesh', 2147483647, 'pcghose@gov.in', 'male', 'pcghose', 'pcghose', 1111, 11),
('meena kumari', 'manipur', 2147483647, 'meena@gov.in', 'female', 'meena', 'meena', 2222, 11),
('k j sengupta', 'andhra pradesh', 2147483647, 'sengupta@gov.in', 'male', 'sengupta', 'sengupta', 3333, 11),
('Mohan', 'Belagavi', 2147483647, 'mohan4444@gov.com', 'female', 'mohan', 'mohan', 4444, 11),
('gopala krishna', 'belagavi', 2147483647, 'gopala5555@gov.in', 'male', 'gopala', 'gopala', 5555, 11),
('Sushma', 'Machenahalli', 27686547, 'sush@gmail.com', 'female', 'sushma', 'sushma', 6666, 11),
('chinna', 'vaynaad', 2147483647, 'cinna@gmail.com', 'male', 'chinna', 'nandan', 7777, 11),
('Ganga', 'Yelchenahalli', 672981736, 'ganga@gmail.com', 'female', 'ganga', 'ganga', 8888, 11),
('sindhu', 'pune', 2147483647, 'sindhu@gmail.com', 'male', 'sindhu', 'sindhu', 9999, 11);

-- --------------------------------------------------------

--
-- Table structure for table `prisoner`
--

CREATE TABLE IF NOT EXISTS `prisoner` (
  `name` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `country` varchar(20) DEFAULT NULL,
  `father_name` varchar(20) NOT NULL,
  `gender` varchar(10) DEFAULT 'male',
  `marital_status` varchar(20) NOT NULL,
  `age` int(12) NOT NULL,
  `section` varchar(20) NOT NULL,
  `sentence` varchar(20) NOT NULL,
  `date_of_admission` date NOT NULL,
  `date_of_release` date DEFAULT NULL,
  `mobile_no` int(15) DEFAULT NULL,
  `account_number` int(15) NOT NULL,
  `height` int(20) NOT NULL,
  `weight` int(12) NOT NULL,
  `known_work` varchar(12) DEFAULT NULL,
  `work_assigned` varchar(20) NOT NULL,
  `identification` varchar(20) DEFAULT NULL,
  `time` time NOT NULL,
  `education` varchar(20) DEFAULT NULL,
  `pid` int(15) NOT NULL,
  `wno` int(15) NOT NULL,
  `sid` int(15) NOT NULL,
  `guid` int(15) NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `sid` (`sid`),
  KEY `wno` (`wno`),
  KEY `guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prisoner`
--

INSERT INTO `prisoner` (`name`, `address`, `country`, `father_name`, `gender`, `marital_status`, `age`, `section`, `sentence`, `date_of_admission`, `date_of_release`, `mobile_no`, `account_number`, `height`, `weight`, `known_work`, `work_assigned`, `identification`, `time`, `education`, `pid`, `wno`, `sid`, `guid`) VALUES
('Umesh Kumar', 'Papareddipalya,Kolar', 'India', 'Rajeeva', 'male', 'unmarried', 20, 'section 420', '12 year', '1998-06-24', '2010-04-28', 2147483647, 123456789, 5, 34, 'cooking', 'kitchen', '6 finger', '20:12:01', 'sslc', 12, 222, 11, 2222),
('Nagappan', 'Rajasthan', 'India', 'Arun', 'male', 'married', 35, 'section 610', '8 years', '2005-06-15', '2013-06-15', 2147483647, 123567898, 5, 45, 'carpenter', 'wood work', '12 finger', '20:11:01', 'puc', 13, 777, 11, 4444),
('Sanjeev kumar', 'Jayaprakash Nagar,Hassan', 'India', 'swamy', 'male', 'married', 26, 'section 120', '20 year', '2003-03-23', '2023-03-23', 123456785, 12345789, 3, 45, 'cooking', 'kitchen', 'birthmark on face', '16:16:16', 'diploma', 14, 444, 11, 3333),
('Mahadevappa', 'goraguntepalya', 'India', 'Kariyappa', 'male', 'unmarried', 27, 'section 510', '10 years', '2001-04-28', '2010-04-28', 2134567890, 14566, 23, 5, 'sculpture', 'cleaning', 'birthmark on face', '10:45:20', 'seventh standard', 15, 555, 11, 5555),
('Krishna', 'Gandhinagar,Chikmagalur', 'India', 'Prakash', 'male', 'married', 37, 'section 120', '20 years', '2002-12-30', '2022-12-30', 2040193450, 234789992, 5, 45, 'construction', 'construction', 'mole on leftleg', '07:23:30', 'uneducated', 16, 333, 11, 5555),
('Shankar', 'Malleshwaram,Banglore', 'India', 'Halappa', 'male', 'unmarried', 27, 'section 377', '25 years', '1999-10-28', '2014-10-28', 2039817839, 23819191, 6, 49, 'electronic', 'electronic', 'mole on left leg', '15:34:46', 'puc', 17, 111, 11, 3333),
('Aditya Hegde', 'Kundapura', 'India', 'Subramanya', 'male', 'unmarried', 38, 'section 610', '8 years', '2016-12-20', '2021-12-20', NULL, 231389123, 5, 45, 'plumber', 'plumber', 'squinted eyes', '09:25:39', 'uneducated', 18, 102, 11, 5555),
('Sachin ', 'Belthangadi,Udupi', 'India', 'Hanumathappa', 'male', 'unmarried', 29, 'section 420', '12 years', '2011-12-12', '2023-12-12', NULL, 342019110, 5, 47, 'mechanic', 'repairer', 'squinted eyes', '14:26:08', 'eighth standard', 19, 101, 11, 5555),
('Chethan', 'Hanasawadi,Shivamogga', 'India', 'Mahadevappa', 'male', 'unmarried', 27, 'section 120', '20 years', '2017-12-11', '2018-12-01', NULL, 123456234, 4, 43, 'carpenter', 'carpenter', '6 fingers in hands', '20:34:12', 'sslc', 20, 888, 11, 4444),
('Rakesh Gadaddar', 'Malali,Davangere', 'India', 'Lakshman', 'male', 'unmarried', 26, 'section 110', '5 years', '2015-03-26', '2020-03-26', NULL, 1234567, 5, 60, 'gold smith', 'cooking', 'wound mark on nose', '19:23:58', 'puc', 21, 666, 11, 1111),
('Dushyantha', 'Kadirenahalli,Kunigal', 'India', 'Narayan', 'male', 'married', 25, 'section 377', '25 years', '1999-11-26', '2024-11-26', NULL, 56885334, 6, 45, 'computerwork', 'cooking', 'birthmark on nose', '15:45:39', 'degree', 22, 111, 11, 4444),
('Harisha', 'Chikkegowdanapalya,Kadur', 'India', 'Manjunatha', 'male', 'unmarried', 40, 'section 401', '18 years', '2018-06-24', '2036-06-24', NULL, 2376489, 5, 60, 'agriculture', 'gardening', 'handicap', '20:12:32', 'uneducated', 24, 999, 11, 1111),
('praveen', 'c/o shahshidhar bellary', 'India', 'shambulinga', 'male', 'married', 45, '321', '25 years', '1998-06-24', '2025-06-24', 1234545, 8763221, 5, 35, 'nothing', 'cleaning', 'short height', '14:26:08', 's.s.l.c', 42, 222, 11, 8888),
('sathish', 's/o sannidhi shivamogga ', 'India', 'sannidhi', 'male', 'single', 27, '401', '5 years', '2011-12-12', '2036-06-24', 23132434, 54321, 5, 65, 'painter', 'cleaning&painting', 'one leg collapsed', '20:34:12', 'MBA', 44, 111, 33, 6666),
('suresh', 'c/o nadaf bangluru karnataka', 'India', 'subbu', 'male', 'single', 19, 'section 420', '35 years', '2003-03-11', '2013-06-15', 19025368, 97531, 6, 97, 'medicalprac', 'health test', 'moleinrighside head', '17:45:12', 'MSc', 66, 333, 33, 4444),
('ramesh', 'nandyaala', '', '', 'male', '', 0, '', 'life imprisonment', '2011-12-12', '0000-00-00', 0, 0, 0, 0, '', '', '', '20:12:32', '', 99, 999, 11, 7777);

-- --------------------------------------------------------

--
-- Table structure for table `remission`
--

CREATE TABLE IF NOT EXISTS `remission` (
  `old_sentence` varchar(20) NOT NULL,
  `decrease_punishment` varchar(20) NOT NULL,
  `date` date DEFAULT NULL,
  `fb_id` int(15) NOT NULL,
  KEY `fb_id` (`fb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remission`
--

INSERT INTO `remission` (`old_sentence`, `decrease_punishment`, `date`, `fb_id`) VALUES
('8  years', '7 ', '2017-12-13', 1),
('20 years', '10', '2014-09-12', 3),
('12 years', '12', '2016-01-13', 12352),
('12 yeras', '3', '2014-10-16', 12351),
('20 years', '10', '2011-11-11', 3),
('3 years', '5', '2018-04-30', 4),
('3 years', '5', '2018-04-30', 4);

-- --------------------------------------------------------

--
-- Table structure for table `superintendent`
--

CREATE TABLE IF NOT EXISTS `superintendent` (
  `name` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `mobile_no` int(10) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `gender` char(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `sup_id` int(20) NOT NULL,
  `wno` int(20) DEFAULT NULL,
  PRIMARY KEY (`sup_id`),
  UNIQUE KEY `wno` (`wno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `superintendent`
--

INSERT INTO `superintendent` (`name`, `address`, `mobile_no`, `email`, `gender`, `username`, `password`, `sup_id`, `wno`) VALUES
('RANGANATH', 'Bangalore', 23456788, 'rangnath42@gmail.com', 'male', 'RANGANATH', 'RANGANATH', 6, 999),
('K GIRIJA SHANKAR', 'BANGALORE', 2147483647, 'GIRIJA@GOV.IN', 'MALE', 'GIRIJA', 'GIRIJA', 11, 111),
('GUNDA CHANDRAIAH', 'MANGALORE', 2147483647, 'GUNDA@GOV.IN', 'MALE', 'GUNDA', 'GUNDA', 22, 222),
('REDDI KANTHA RAO', 'UTTARA', 2147483647, 'RAO@GOV.IN', 'MALE', 'RAO', 'RAO', 33, 333),
('NIKHILESH', 'C/o reddy', 1722143143, 'acharil04@gmail.com', 'male', 'NIKHILESH', 'NIKHILESH', 454, 101);

-- --------------------------------------------------------

--
-- Table structure for table `transfer_to`
--

CREATE TABLE IF NOT EXISTS `transfer_to` (
  `from_prison` varchar(50) NOT NULL,
  `to_prison` varchar(50) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `transfer_id` int(15) NOT NULL,
  `pno` int(15) DEFAULT NULL,
  PRIMARY KEY (`transfer_id`),
  UNIQUE KEY `pno` (`pno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transfer_to`
--

INSERT INTO `transfer_to` (`from_prison`, `to_prison`, `reason`, `transfer_id`, `pno`) VALUES
('Central Prison Ramnagaram', 'Central Prison Gulbarga', 'SECURITY PURPOSE', 1, 12),
('Central Prison Ramnagaram', 'Central Prison Vijayawada', 'Helath Issues', 2, 13),
('Central Prison Ramnagaram', 'Central Prison Banglore', 'On request by prisoner', 3, 17),
('udupi district jail', 'central jail banglore', 'bad behavior', 4, 21),
('parappana agrahara banglore', 'central jail banglore', 'work based', 6, 22),
('district jail mangaluru', 'Central Prison Vijayawada', 'good behaivur', 8, 18),
('Central Prison Belagavi', 'parappana agrahara banglore', 'lack of space', 10, 14),
('central prison belagavi', 'central prison vijayawada', 'bad behaviour', 11, 15),
('parappana agrahara banglore', 'district jail chikkmangluru', 'health issue', 44, 19);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedbackby_guard`
--
ALTER TABLE `feedbackby_guard`
  ADD CONSTRAINT `feedbackby_guard_ibfk_1` FOREIGN KEY (`guid`) REFERENCES `guard` (`gid`),
  ADD CONSTRAINT `feedbackby_guard_ibfk_2` FOREIGN KEY (`pno`) REFERENCES `prisoner` (`pid`);

--
-- Constraints for table `feedbackby_sup`
--
ALTER TABLE `feedbackby_sup`
  ADD CONSTRAINT `feedbackby_sup_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `superintendent` (`sup_id`),
  ADD CONSTRAINT `feedbackby_sup_ibfk_2` FOREIGN KEY (`fb_id`) REFERENCES `feedbackby_guard` (`feedback_id`);

--
-- Constraints for table `guard`
--
ALTER TABLE `guard`
  ADD CONSTRAINT `guard_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `superintendent` (`sup_id`);

--
-- Constraints for table `prisoner`
--
ALTER TABLE `prisoner`
  ADD CONSTRAINT `prisoner_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `superintendent` (`sup_id`),
  ADD CONSTRAINT `prisoner_ibfk_2` FOREIGN KEY (`wno`) REFERENCES `court` (`warrentno`),
  ADD CONSTRAINT `prisoner_ibfk_3` FOREIGN KEY (`guid`) REFERENCES `guard` (`gid`);

--
-- Constraints for table `remission`
--
ALTER TABLE `remission`
  ADD CONSTRAINT `remission_ibfk_1` FOREIGN KEY (`fb_id`) REFERENCES `feedbackby_guard` (`feedback_id`);

--
-- Constraints for table `superintendent`
--
ALTER TABLE `superintendent`
  ADD CONSTRAINT `superintendent_ibfk_1` FOREIGN KEY (`wno`) REFERENCES `court` (`warrentno`);

--
-- Constraints for table `transfer_to`
--
ALTER TABLE `transfer_to`
  ADD CONSTRAINT `transfer_to_ibfk_1` FOREIGN KEY (`pno`) REFERENCES `prisoner` (`pid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
