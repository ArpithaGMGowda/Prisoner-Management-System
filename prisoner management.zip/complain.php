<?php
$host="localhost";
		$user="root";
		$pass="root";
		$db="ma";
		$conn=mysqli_connect($host,$user,$pass,$db);
		$subject1="";
		$message1="";
		$fb_id="";
		$sid="";
		$date="";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try{
	$conn=mysqli_connect($host,$user,$pass,$db);

}catch(MYSQLI_sql_Exception $ex){
	echo ("error error");
}
function getData(){
	$data=array();
	$data[0]=$_POST['subject1'];
	$data[1]=$_POST['message1'];
	$data[2]=$_POST['fb_id'];
	$data[3]=$_POST['sid'];
	$data[4]=$_POST['date'];
	return $data;
}
if(isset($_POST['Insert'])){
	$info=getData();
	$insert_query="INSERT INTO `feedbackby_sup`(`subject1`, `message1`, `fb_id`, `sid`, `date`)VALUES ('$info[0]','$info[1]','$info[2]','$info[3]','$info[4]')";

	try{
		//echo("hi");
		$insert_result=mysqli_query($conn,$insert_query);
			//echo("helo");
		if($insert_result){
			if(mysqli_affected_rows($conn)>0){
				       $mess="Data inserted successfully";
			echo "<script type='text/javascript'>alert('$mess');</script>";

			}
			else{

				$mess="No data inserted";
			echo "<script type='text/javascript'>alert('$mess');</script>";
			}
		}
	}catch(Exception $e){
			echo ('error inserted');
			echo $e->getMessage();

	
}

}


?>
<html>
<head>
<title> Feedback Form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table width="100%" height="91" border="0" align="center" bgcolor="silver">
<tr>
<td height="33" align="center" bgcolor="black">
<font size="5">
<a href="admin.php">Home</a> 
</font>
</td>
</tr>
<td height="5"><tr>
<td>
<h4 style="color:black;" align="center">
	Superintendent Feedback entry<br>
-----------------------------------------------
</h4>
<div>
	<center>
	
<form action="complain.php" method="post">
		<ul>
		<b>Subject:			</b><input type ="text" name="subject1" placeholder="subject1" value="<?php echo($subject1);?>"><br><br>
		
		<b>Message:			</b><input type ="text" name="message1" placeholder="message1" value="<?php echo($message1);?>"><br><br>
		
		<b>Feedback_id:		</b><input type ="number" name="fb_id" placeholder="fb_id" value="<?php echo($fb_id);?>"><br><br>
		<b>Superintendent ID:		</b><input type ="number" name="sid" placeholder="sid" value="<?php echo($sid);?>"><br><br>
		<b>Date:		</b><input type ="date" name="date" placeholder="date" value="<?php echo($date);?>"><br><br>
    <br>
  
 </tr>
 <td align="center"><input type="submit" name="Insert" value="Add" /></td>
</table>
</ul>
</form>
</center>


<tr>
	<center>
<a href="admin.php"><<<<<button>BACK</button><<<<</a></center>
<br>
<center><td height="21" colspan="2" align="center" bgcolor="silver"> 2018 BENGALURU PRISON SERVICES</td></center>
</tr>
</td>
</div>
</table>
</body>
</html>
