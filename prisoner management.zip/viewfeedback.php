<html>
<head>
  <title>View Prisoners  </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='1200' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='#999999' valign='center'>


<?php

$host="localhost";
$username="root";
$password="root";
$db_name="ma";

$conn=mysqli_connect("$host","$username","$password") or die("cannot connect");
mysqli_select_db($conn,"$db_name")or die("cannot connect");

$sel= mysqli_query($conn,"select p.name,f.subject,f.message,f.feedback_id,f.guid,f.pno,count(*) from feedbackby_guard as f ,prisoner as p where f.pno=p.pid group by f.pno,f.guid having count(*)>=1");
echo"<table align='center' width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='green'>
<caption><h3>PRISONER FEEDBACK INFORMATION</h3></caption>
<tr bgcolor='silver'>
<th width='15%'>Feedback_id</th>
<th width='10%'>Name</th>
<th width='3%'>Prisoner ID</th>
<th width='15%'>Guard ID</th>
<th width='10%'>Subject</th>
<th width='10%'>Message</th>
<th width='15%'>Count</th>



</tr>";

   while($row=mysqli_fetch_array ($sel))
{
echo "<tr bgcolor='white'>";

echo  "<td width='3%'>".$row ['feedback_id']."</td>";
echo  "<td width='3%'>".$row ['name']."</td>";
echo  "<td width='7%'>".$row ['pno']."</td>";
echo  "<td width='10%'>".$row ['guid']."</td>";
echo  "<td width='10%'>".$row ['subject']. "</td>";
echo  "<td width='10%'>".$row ['message']."</td>";
echo  "<td width='3%'>" .$row ['count(*)']."</td>";


echo "</tr>";
}
echo"</table>";

?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center"><a href="guard.php" target="_parent"> [Guard Panel] <b></b></a>
			<a href='search-form.php' target="_parent"> [Back] </a></td>
		
          </tr>
          <tr>
            <td align='center' bgcolor='white' height='1'>
					
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					2018 BENGALURU PRISON SERVICES
            </td>
          </tr>
	</table>
</body>
</head>
</html>
